#ifndef CONFIGROBOT_cpp
#define CONFIGROBOT_cpp

#include "ConfigRobot.h"

ConfigRobot::ConfigRobot()
{
	int mode=0;
	run=0;
	ts=5;
	pidDebug=0;
	EEPROM.get(AWIND_ADDR,awindUp); 
	EEPROM.get(PIDTS_ADDR,ts); 	
	EEPROM.get(MODO_ADDR,mode); 
	setMode(mode);
	mode=0;	
	
}

void ConfigRobot::setMode(int t)
{
	if (t>=0 && t<=2)
	{
		_mode=t;
	}
}

int ConfigRobot::getMode()
{
	int p=_mode;
	return p;	
}

#endif