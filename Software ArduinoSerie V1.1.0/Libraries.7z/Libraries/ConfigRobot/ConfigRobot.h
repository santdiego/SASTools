#ifndef CONFIGROBOT_h
#define CONFIGROBOT_h
#include <EEPROM.h>

#define FORMATO_ADDR  200
#define MODO_ADDR     205
#define AWIND_ADDR    210
#define PIDRST_ADDR   215	
#define PIDTS_ADDR    220	

class ConfigRobot
{
	public:
		ConfigRobot();	
		bool run;			//run=0( Modo STOP/Configuracion)  run=1 (Modo RUN)
		int	ts;				//Tiempo de muestreo
		int awindUp;		//Seteo de anti wind up
		int pidDebug;		
		void setMode(int t);
		int getMode();
		
	private:	
		int _mode;				//(0) Torque, (1) Posicion 
		
		
	
		
};
#endif