#ifndef ASCIICOMMAND_cpp
#define ASCIICOMMAND_cpp

#include "AsciiCommand.h"


AsciiCommand::AsciiCommand()
{
	_com="";
	_num=0;
	EEPROM.get(FORMATO_ADDR,_wformat);
}

void AsciiCommand::read(String StrInput)
{
  //++++SPLIT COMMAND AND NUMBER+++++++++++++++++++

  int i=0;

  int n=StrInput.length();
  
  char c;
  _com="";
  _num=0;
  
  StrInput.toUpperCase();
  StrInput[n-1]=0;
  _com=StrInput;

  
  while(i<n && c!=' ')
  {
    c=StrInput[++i];
    
    if(c==' ')
    {
      _com=StrInput.substring(0,i);
      _num=StrInput.substring(i+1,n).toFloat();
      
    }        
  }
  

	return;
	
}

void AsciiCommand::set(ConfigRobot& rob,Qrobot& q0,Qrobot& q1,Qrobot& q2,Qrobot& q3,Qrobot& q4,Qrobot& q5,Qrobot& q6,Qrobot& q7)
{
	

	if(_com=="Q0:KP")	qCompute("Kp",q0.kp, q0.addr);
	if(_com=="Q0:KP?")	qCompute("Kp",q0.kp);
	if(_com=="Q1:KP")	qCompute("Kp",q1.kp, q1.addr);
	if(_com=="Q1:KP?")	qCompute("Kp",q1.kp);
	if(_com=="Q2:KP")	qCompute("Kp",q2.kp, q2.addr);
	if(_com=="Q2:KP?")	qCompute("Kp",q2.kp);
	if(_com=="Q3:KP")	qCompute("Kp",q3.kp, q3.addr);
	if(_com=="Q3:KP?")	qCompute("Kp",q3.kp);
	if(_com=="Q4:KP")	qCompute("Kp",q4.kp, q4.addr);
	if(_com=="Q4:KP?")	qCompute("Kp",q4.kp);
	if(_com=="Q5:KP")	qCompute("Kp",q5.kp, q5.addr);
	if(_com=="Q5:KP?")	qCompute("Kp",q5.kp);
	if(_com=="Q6:KP")	qCompute("Kp",q6.kp, q6.addr);
	if(_com=="Q6:KP?")	qCompute("Kp",q6.kp);
	if(_com=="Q7:KP")	qCompute("Kp",q7.kp, q7.addr);
	if(_com=="Q7:KP?")	qCompute("Kp",q7.kp);


	if(_com=="Q0:KI")	qCompute("Ki",q0.ki, q0.addr+5);
	if(_com=="Q0:KI?")	qCompute("Ki",q0.ki);
	if(_com=="Q1:KI")	qCompute("Ki",q1.ki, q1.addr+5);
	if(_com=="Q1:KI?")	qCompute("Ki",q1.ki);
	if(_com=="Q2:KI")	qCompute("Ki",q2.ki, q2.addr+5);
	if(_com=="Q2:KI?")	qCompute("Ki",q2.ki);
	if(_com=="Q3:KI")	qCompute("Ki",q3.ki, q3.addr+5);
	if(_com=="Q3:KI?")	qCompute("Ki",q3.ki);
	if(_com=="Q4:KI")	qCompute("Ki",q4.ki, q4.addr+5);
	if(_com=="Q4:KI?")	qCompute("Ki",q4.ki);
	if(_com=="Q5:KI")	qCompute("Ki",q5.ki, q5.addr+5);
	if(_com=="Q5:KI?")	qCompute("Ki",q5.ki);
	if(_com=="Q6:KI")	qCompute("Ki",q6.ki, q6.addr+5);
	if(_com=="Q6:KI?")	qCompute("Ki",q6.ki);
	if(_com=="Q7:KI")	qCompute("Ki",q7.ki, q7.addr+5);
	if(_com=="Q7:KI?")	qCompute("Ki",q7.ki);

	if(_com=="Q0:KD")	qCompute("Kd",q0.kd, q0.addr+10);
	if(_com=="Q0:KD?")	qCompute("Kd",q0.kd);
	if(_com=="Q1:KD")	qCompute("Kd",q1.kd, q1.addr+10);
	if(_com=="Q1:KD?")	qCompute("Kd",q1.kd);
	if(_com=="Q2:KD")	qCompute("Kd",q2.kd, q2.addr+10);
	if(_com=="Q2:KD?")	qCompute("Kd",q2.kd);
	if(_com=="Q3:KD")	qCompute("Kd",q3.kd, q3.addr+10);
	if(_com=="Q3:KD?")	qCompute("Kd",q3.kd);
	if(_com=="Q4:KD")	qCompute("Kd",q4.kd, q4.addr+10);
	if(_com=="Q4:KD?")	qCompute("Kd",q4.kd);
	if(_com=="Q5:KD")	qCompute("Kd",q5.kd, q5.addr+10);
	if(_com=="Q5:KD?")	qCompute("Kd",q5.kd);
	if(_com=="Q6:KD")	qCompute("Kd",q6.kd, q6.addr+10);
	if(_com=="Q6:KD?")	qCompute("Kd",q6.kd);
	if(_com=="Q7:KD")	qCompute("Kd",q7.kd, q7.addr+10);
	if(_com=="Q7:KD?")	qCompute("Kd",q7.kd);

	if(_com=="Q0:TD")	qCompute("Td",q0.td, q0.addr+15);
	if(_com=="Q0:TD?")	qCompute("Td",q0.td);
	if(_com=="Q1:TD")	qCompute("Td",q1.td, q1.addr+15);
	if(_com=="Q1:TD?")	qCompute("Td",q1.td);
	if(_com=="Q2:TD")	qCompute("Td",q2.td, q2.addr+15);
	if(_com=="Q2:TD?")	qCompute("Td",q2.td);
	if(_com=="Q3:TD")	qCompute("Td",q3.td, q3.addr+15);
	if(_com=="Q3:TD?")	qCompute("Td",q3.td);
	if(_com=="Q4:TD")	qCompute("Td",q4.td, q4.addr+15);
	if(_com=="Q4:TD?")	qCompute("Td",q4.td);
	if(_com=="Q5:TD")	qCompute("Td",q5.td, q5.addr+15);
	if(_com=="Q5:TD?")	qCompute("Td",q5.td);
	if(_com=="Q6:TD")	qCompute("Td",q6.td, q6.addr+15);
	if(_com=="Q6:TD?")	qCompute("Td",q6.td);
	if(_com=="Q7:TD")	qCompute("Td",q7.td, q7.addr+15);
	if(_com=="Q7:TD?")	qCompute("Td",q7.td);

    
	if(_com=="RUN")	rob.run=1;

	if(_com=="MODO")
	{

		switch((int)_num)
		{
		case 0: 			//Control Manual o de torque
			rob.setMode(0);
			EEPROM.put(MODO_ADDR,0);
			break;
			
		case 1:				//Control de Posicion 
			rob.setMode(1);
			EEPROM.put(MODO_ADDR,1);
			break;
			
		//case 2:
			//rob.setMode(1);
			//EEPROM.put(MODO_ADDR,1);
			//break;
			
		default:
			//rob.setMode(0);
			//EEPROM.put(MODO_ADDR,0);
			break;
		}
	}

	if(_com=="AWINDUP?")
	{
		Serial.print("Anti WindUp: ");
		if (rob.awindUp)
			Serial.println("Activado");
		else	
			Serial.println("Desactivado");
	}
	
	if(_com=="AWINDUP")
	{
		switch((int)_num)
		{
			case 0:
				rob.awindUp=0;
				break;
			case 1:
				rob.awindUp=1;
				break;
			default:
				rob.awindUp=1;
				break;	
		}
		
		EEPROM.put(AWIND_ADDR,rob.awindUp);
		Serial.print("Anti WindUp: ");
		if (rob.awindUp)
			Serial.println("Activado");
		else	
			Serial.println("Desactivado");
		
	}
	
	
	if(_com=="PIDDEBUG?")
	{
		Serial.print("PID Debug: ");
		if (rob.pidDebug)
			Serial.println("Activado");
		else	
			Serial.println("Desactivado");
	}
	
	if(_com=="PIDDEBUG")
	{
		switch((int)_num)
		{
			case 0:
				rob.pidDebug=0;
				break;
			case 1:
				rob.pidDebug=1;
				break;
			default:
				rob.pidDebug=1;
				break;	
		}
		
		Serial.print("PID Debug: ");
		if (rob.pidDebug)
			Serial.println("Activado");
		else	
			Serial.println("Desactivado");
	}	
	

	if(_com=="MODO?")
	{
		
		Serial.print("Modo actual: ");
		switch(rob.getMode())
		{
		case 0:
			Serial.println("Control de torque o manual");
			break;
			
		case 1:
			Serial.println("Control de posicion");
			break;
		case 2:
			Serial.println("Control de Velocidad ");
			break;
		}
						
	}

	if(_com=="TS?")
	{
		Serial.print("Ts: ");
		Serial.print(rob.ts);
		Serial.println(" ms");
	}

	if(_com=="TS")
	{
		
		
		if(_num >= 5)
			rob.ts=(int)_num;

		else		
			rob.ts=10;
		
		
		EEPROM.put(PIDTS_ADDR,rob.ts);
		Serial.print("Ts configurado: ");			
		Serial.print(rob.ts);
		Serial.println(" ms");		
		
		
			
		
	}	

	
	if(_com=="COMANDOS?")	printHelp();
	
	if(_com=="ESTADO?")
	{
		if(!rob.run) 
			Serial.println("Estado: STOP/Configuracion");
		else	
			Serial.println("Estado: RUN/En marcha");
	}

	if(_com=="FORMATO")	
	{
		switch((int)_num)
		{
			case 0:
				_wformat=0;
				break;
			case 1:
				_wformat=1;
				break;
			default:
				_wformat=1;
				break;	
		}
		
		EEPROM.put(FORMATO_ADDR,_wformat);
		if(_wformat)
			Serial.println("Imprimiendo con formato..");
		else
			Serial.println("Imprimiendo sin formato..");
	}		
	


}  


//++++++++++++++++++++++++++++++++++++++++++++PRINT FUNCTIONS+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void AsciiCommand::qCompute(String str_toPrint, float& val,const int& addr)
{
	
	val=_num;  
	EEPROM.put(addr, val);
	 
    if(_wformat)
    { 
		Serial.print("Recibido, ");
        Serial.print(str_toPrint);
        Serial.print("=");
		Serial.print(val*1000);
		Serial.println("e-3");
	}
	else
	{
		Serial.println("OK");
	}
}

void AsciiCommand::qCompute(String str_toPrint,const float& val)
{

	
	if(_wformat)
	{	  
		Serial.print(str_toPrint);
		Serial.print("=");
	}
	
		Serial.print(val*1000);
		Serial.println("e-3");
	
}


void AsciiCommand::printHelp()
{
           
	Serial.println("Q0:[KP/KI/KD/TD]?   Obtiene KP/KI/KD/TD de la articulacion Q0");
	Serial.println("Q0:[KP/KI/KD/TD] X  Setea KP/KI/KD/TD=X en Q0");
	Serial.println("Q0:KP X             Setea KP en Q0");		
	Serial.println("RUN                 Da inicio a la lectura/escritura de tramas");  
	Serial.println("MODO X              Setea modo de control, 0->Torque o manual / 1->Control de posicion");
	Serial.println("MODO?               Obtiene el modo de control actual");
	Serial.println("FORMATO X           Setea mensajes con formato, 1->Con formato /0->Sin formato"); 
	Serial.println("TS?                 Obtiene el tiempo de muestreo actual para el control de motores");
	Serial.println("TS                  Configura el tiempo de muestreo para el control de motores");
	Serial.println("PIDDEBUG            Coloca el PID con modo depuración");	
    Serial.println("PIDDEBUG?           Obtiene el estado de depuración");	
	Serial.println("COMANDOS?           Obtiene lista de comandos");
	Serial.println();
	Serial.println();
	
}
#endif