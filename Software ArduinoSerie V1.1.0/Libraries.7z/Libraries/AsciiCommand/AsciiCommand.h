#ifndef ASCIICOMMAND_h
#define	ASCIICOMMAND_h

#include "ConfigRobot.h"
#include "Qrobot.h"
#include "Arduino.h"
#include <EEPROM.h>

class AsciiCommand
{
	public:
		AsciiCommand();
		void read(String StrInput);
		void set(ConfigRobot& rob,Qrobot& q0,Qrobot& q1,Qrobot& q2,Qrobot& q3,Qrobot& q4,Qrobot& q5,Qrobot& q6,Qrobot& q7);
		void printHelp();

		
	private:
		bool _wformat;
		String _com;
		float _num;
		void qCompute(String str_toPrint, float& val,const int& addr);
		void qCompute(String str_toPrint,const float& val);	
		void printInfo();
		
		

		
};
#endif