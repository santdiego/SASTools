#ifndef QROBOT_h
#define QROBOT_h

//#include "TimerThree.h"
#include "ConfigRobot.h"
#include "Adafruit_MotorShield.h"
#include "utility/Adafruit_PWMServoDriver.h"
#include <Wire.h>
#include <EEPROM.h>

#define FORMATO_ADDR  200
#define MODO_ADDR     205
#define AWIND_ADDR    210
#define PIDRST_ADDR   215

class Qrobot
{
   public:
   
      float kp;         //Parametros del controlador por defecto
      float ki;
      float kd;   
      float td;
      int addr;
   
      Qrobot(int pmin, int pmax, int pinPwm, int pinPot,int pinDir, int pinBrk, int pidParamsAddr);
      Qrobot(int pmin, int pmax, int pinPot, int pidParamsAddr);
      
      float readG();
      unsigned int read();
      unsigned int pidCompute(ConfigRobot& p , unsigned int ref);      

      void release(Adafruit_DCMotor* motor);
      void release();      
      void write(unsigned int u,Adafruit_DCMotor* motor);
      void write(unsigned int u);
      void pidFlush();      
   
   private:
   
   
      //--pines-----   
      int _pinDir;  //Sentido de giro
      int _pinBrk;  //Brake Motor
      int _pinPwm;  //PWM Motor
      int _pinPot;
      
      //--Posiciones max/min y tipo de shield-----
      int _posMin;
      int _posMax;
      int _dir;

      //--Variable del PID-----
      float erMax;
      float erMaxL;
      float erMaxH;
      float _er0;
      float _er1;
      float _P;
      float _I0;
      float _I1;
      float _D0;
      float _D1;
      float _y0;
      float _y1;
      float _u0;
      float _u1;
      float _ref;   
      
      //--Promedios
      float _p0;
      float _p1;
      float _p2;
      float _p3;
      float _p4;
      float _p5;
      float _p6;   
      float _p7;   
      float _p8;         
      
      float _m1;
      float _m2;
      float _m3;
      float _m4;
      float _m5;
      
      
         
      
};
#endif
