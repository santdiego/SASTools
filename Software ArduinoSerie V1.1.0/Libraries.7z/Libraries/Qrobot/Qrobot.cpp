#ifndef QROBOT_cpp
#define QROBOT_cpp

#include "Qrobot.h"


Qrobot::Qrobot(int pmin, int pmax, int pinPwm, int pinPot,int pinDir, int pinBrk, int pidParamsAddr) //Arduino Motor Shield
{

	_posMin=pmin;
	_posMax=pmax;
	
	_pinPwm=pinPwm;
	_pinPot=pinPot;
	_pinDir=pinDir;  
	_pinBrk=pinBrk; 


	_m1=(float)(_posMax-_posMin)/(float)4095;
	_m2=(float)4095/(float)5;
	_m3=(float)180/(float)4095;
	_m4=(float)5/(float)4095;
	_m5=(float)255/(float)4095;		

	
	addr=pidParamsAddr;
	
	EEPROM.get(addr,kp);			
	EEPROM.get(addr+5,ki);
	EEPROM.get(addr+10,kd);
	EEPROM.get(addr+15,td);
	pidFlush();	
	_dir=0;
	erMax=80;
	
}

Qrobot::Qrobot(int pmin, int pmax, int pinPot, int pidParamsAddr)									//Adafruit Motor shield
{

	_posMin=pmin;
	_posMax=pmax;

	_pinPwm=0;
	_pinPot=pinPot;
	_pinDir=0;  
	_pinBrk=0; 
	
	_m1=(float)(_posMax-_posMin)/4095;
	_m2=(float)4095/5;
	_m3=(float)180/4095;
	_m4=(float)5/4095;
	_m5=(float)255/4095;			
	
	addr=pidParamsAddr;
	
	EEPROM.get(addr,kp);			
	EEPROM.get(addr+5,ki);
	EEPROM.get(addr+10,kd);
	EEPROM.get(addr+15,td);
	pidFlush();	
	_dir=0;
	erMax=80;
	erMaxL=(int)erMax;
	erMaxH=(int)erMax*2;
}

float Qrobot::readG()
{
  float p=(float)read();
  p=p*_m3;				//0-4095 to 0-180     
   
  return p; 
}

unsigned int Qrobot::read()
{	

  unsigned int i=analogRead(_pinPot); //Conversor A/D 10b, i=0-1023  
  //Serial.print("i=");Serial.println(i);
  
   //Filtro de media movil n=5
   float suma=_p0+_p1+_p2+_p3+_p4+i;
   _p4=suma/6;
   i=(unsigned int)_p4;
   //_p7=_p8;
   //_p6=_p7;
   //_p5=_p6; 
   //_p4=_p5;
   _p3=_p4;
   _p2=_p3;
   _p1=_p2;
   _p0=_p1;
			   
   //---------------------------
 
  return i;
}

unsigned int Qrobot::pidCompute(ConfigRobot& rob , unsigned int ref)
{
	
    //int tpo = micros();
	
	unsigned int uint=0;
	
	_y1=read();
	if(rob.pidDebug) 
	{Serial.print("y1: ");Serial.println(_y1);}
	
	_ref=ref*_m1+_posMin;							//(_ref=ref*(_posMax-_posMin)/4095 +_posMin;
	if(rob.pidDebug) 
	{Serial.print("ref: ");Serial.println(_ref);}
	
	_er1=_ref-_y1; 
	if(rob.pidDebug)
	{Serial.print("_er1: ");Serial.println(_er1);}
		
	_P=kp*_er1;
	if(rob.pidDebug)
	{Serial.print("_P: ");Serial.println(_P);}

	if(rob.awindUp)
	{
		if(abs(_er1)<=erMax)			
			_I1=_I0+rob.ts*0.0005*(_er1+_er0);
		else				
			_I1=0;						
	}
	else
		_I1=_I0+rob.ts*0.0005*(_er1+_er0);			//(ts/1000)*(1/2)=1/2000=ts*.0005
				
	if(rob.pidDebug)
	{Serial.print("_I1: ");Serial.println(_I1);}
	
	_D1=td*(_D0-kd*(_y1-_y0));	
	if(rob.pidDebug)
	{Serial.print("_D1: ");Serial.println(_D1);}
	
	_u1=_P+ki*_I1+kd*_D1;
	if(rob.pidDebug)
	{Serial.print("u1: ");Serial.println(_u1);}
		
	if(_u1> 5) _u1= 5;
	if(_u1<-5) _u1=-5;


	
	_u0=_u1;
	_er0=_er1;
	_y0=_y1;
	_I0=_I1;
	_D0=_D1;		
	
	//float j=_u1*_m2; // 0-5 to 0-4095
	
	if(_u1<0)
	{
		
		uint=(unsigned int)(abs(_u1)*_m2);	
		uint=uint+32768;
		//uint=uint | 0x8000;
	
	}else{
		uint=(unsigned int)(_u1*_m2);
	}
	
	
	//int resta = micros() - tpo;	
	//Serial.println(resta);
	
	return uint;	
}
 
 
 void Qrobot::release(Adafruit_DCMotor* motor)
 {
		 
	motor->run(RELEASE);
	pidFlush(); 

 }
 
 void Qrobot::release() 			//-------------Arduino motor shield
 {
	 
	 analogWrite(_pinPwm,0);
	 digitalWrite(_pinBrk, LOW);
	 
 }
 
 void Qrobot::write(unsigned int u)		//-------------Arduino motor shield
 {
	unsigned int u1;
	if(u==0)
	{	
		digitalWrite(_pinDir,LOW);
		digitalWrite(_pinBrk,HIGH);
		//analogWrite(_pinPwm,255);
		analogWrite(_pinPwm,0);
	}else{
	
	//if(u>0 && u<4096) //valor de accion de control positiva
	if(u>0 && u<32768)
		
	//if(u & 0x8000 ==0)
	{
		if(u>4095) {
			u=4095;
		}

		u1=map(u, 0, 4095, 0 ,255);
		//u1=(unsigned int)((float)u*_m5); //	_m5=(float)255/4095;	
		
		digitalWrite(_pinDir,HIGH);
		digitalWrite(_pinBrk,LOW);		
			
		//Serial.print("u= +");Serial.println(u);				
		analogWrite(_pinPwm, u1);
	}else{
	//if(u>4095 && u<8192)//valor de accion de control negativa

	

		//u=u-4096;
		u=u-32768;
		//u=u & 0x7FFF;
		if(u>4095) {
			u=4095;
		}
		//u1=(unsigned int)((float)u*_m5); //	_m5=(float)255/4095;	

		digitalWrite(_pinDir,LOW);
		digitalWrite(_pinBrk,LOW);

		u1=map(u, 0, 4095, 0 ,255);
	
		//Serial.print("u= -");Serial.println(u);				
		analogWrite(_pinPwm, u1);
	}	
	}
 }
 

 void Qrobot::write(unsigned int u, Adafruit_DCMotor* motor) //Adafruit motor shield
 {
	//int tpo=micros();

	if(u==0){
		motor->setSpeed(u); 
		//motor->run(BRAKE); 
	}else{
	//if(u<4096)
	if(u>0 && u<32768)
	//if(u & 0x8000 ==0)
	{
		if(u>4095) {
			u=4095;
		}
		motor->setSpeed(u);  	//Asigno PWM a Motor
		
		if (_dir==-1 || !_dir)
		{
			motor->run(FORWARD);    //Giro Motor1 Adelante
			_dir=1;
		}
	}else{

	
	//if(u>4095 && u<8192 )
	//{
		
		//u=u-4096;
		//u=u & 0x7FFF;
		u=u-32768;
		if(u>4095) {
			u=4095;
		}
		motor->setSpeed(u);  //Asigno PWM a Motor

		if (_dir==1 || !_dir)
		{
			motor->run(BACKWARD);   //Giro Motor1 Atras}
			_dir=-1;
		}
	}
	}
	
	//Serial.println("");
	//int resta=micros()-tpo;
    //Serial.println(resta); 
	 
 } 
 
  void Qrobot::pidFlush()
 {
	_p1=0;
	_p0=0;
	
	_er0=0;
	_er1=0;

	_P=0;
	_I0=0;
	_I1=0;
	_D0=0;
	_D1=0;
	_y0=0;
	_y1=0;

	_u0=0;
	_u1=0;		
	 
 }
 #endif